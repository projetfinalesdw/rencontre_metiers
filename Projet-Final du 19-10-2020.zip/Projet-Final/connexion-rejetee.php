<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		
	</head>
	<body>
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="index.html"><img src="img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
								<nav class="hide">
										<a href="index.html">Home</a>
										<!-- <a href="generic.html">Matériaux ou produits</a> -->
										<a href="annonces/">Services ou emplois</a>
										<a href="forum.html">Forums</a>
									</nav>

									<nav class="login">
									<a href="inscription.html">Créer un compte</a>
										<a href="#openModal14">Se connecter</a>
										
									</nav>
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="main-wrapper">

	
		<div class="banner-area">
				<div class="container">
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-4 col-md-6 col-sm-12">
							<img class="img-fluid mx-auto d-flex" src="img/header-img.png" alt="">
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 pb-40">
							<div class="banner-content">


							<?php

				
	
            echo "<div class='alert alert-danger mt-4' role='alert'>L'email ou le mot de passe sont incorrects!
            <p><a href='login.html'><strong>Veuillez réessayer!</strong></a></p></div>";			
	



        ?>
                                
					


								
								<div id="openModal14" class="modalDialog">
								<div>
									<a href="#close" title="Close" class="close">X</a>
									<h4 class="modal-titre">Connexion</h4>
								
														<form action="check-connexion.php" method="post">                           	
															<div class="form-group">									
																<input type="email" class="form-control input-lg" name="email" placeholder="Email" required>        
															</div>							
															<div class="form-group">        
																<input type="password" class="form-control input-lg" name="password" placeholder="Password" required>       
															</div>								    
															<button class="primary-btn hover d-inline-flex align-items-center" style="width:100%;margin-bottom: 2em;"><span class="mr-10" style="
																margin-left: 7em;
															">Se connecter</span><span class="lnr lnr-arrow-right"></span></button>
														</form>
														<!-- Collapse a form when user click Lost your password? link-->
														<p style="text-align: center;"><a href="#showForm" data-toggle="collapse" aria-expanded="false" aria-controls="collapse" style="
											color: #111;
										" class="collapsed">Mot de passe perdu?</a></p>		
														<div class="collapse" id="showForm">
															<div class='well'>
																<form action="viewsfilms/recuperation-password.php" method="post">
																	<div class="form-group">										
																		<input type="email" class="form-control" name="email" placeholder="Saisissez l'email associé au mot de passe." required>
																	</div>
																	<button type="submit" class="btn btn-dark rec">Récupérer mot de passe</button>
																</form>								
															</div>
														</div>
																				
														<hr><p class="txpop">Vous n'avez pas encore de compte? <a href="s'inscrire.html" title="Create an account">Créez-en un ici</a>.</p>								
							
								</div>
							</div>						

							</div>
						</div>
					</div>
				</div>
			</div>				

			
			<!-- Start Footer Section -->
			<footer class="footer-area pt-100 pb-20">
				<div class="container">
					<div class="row">
					
						
					
					
					
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						<p class="footer-text m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</div>
				</div>
			</footer>
			<!-- End Footer Section -->
		</div>
		<script src="js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="js/vendor/bootstrap.min.js"></script>
		<script src="js/jquery.ajaxchimp.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.nice-select.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/main.js"></script>
        
	</body>
</html>




