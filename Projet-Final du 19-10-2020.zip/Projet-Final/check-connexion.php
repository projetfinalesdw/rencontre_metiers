<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
       
	</head>
	<body>
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="#"><img src="img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
								<nav class="hide">
										<a href="#">Home</a>
										<!-- <a href="generic.html">Matériaux ou produits</a> -->
										<a href="annonces/">Services ou emplois</a>
										<a href="forum.html">Forums</a>
									</nav>

									
									<?php
										// Connection info. file
										include "BD/connexion.inc.php";	
										
										// Connection variables
										/*    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname); */

										// Check connection
										if (!$connexion) {
											die("Connection failed: " . mysqli_connect_error());
										}
										
										// data sent from form login.html 
										$email = $_POST['email']; 
										$password = $_POST['password'];
										
										// Query sent to database
										$result = mysqli_query($connexion, "SELECT * FROM membres WHERE Email = '$email'");
										
										// Variable $row hold the result of the query
										$row = mysqli_fetch_assoc($result);
										$_SESSION['membre']=$row;
										
										
										// Variable $hash hold the password hash on database
										$hash = $row['Password'];
										
										/* 
										password_Verify() function verify if the password entered by the user
										match the password hash on the database. If everything is OK the session
										is created for one minute. Change 1 on $_SESSION[start] to 5 for a 5 minutes session.
										*/
										if (password_verify($_POST['password'], $hash)) {	
											
											
											$_SESSION['loggedin'] = true;
											$_SESSION['id'] = $row['Id'];
											$_SESSION['nom'] = $row['Nom'];
											$_SESSION['prenom'] = $row['Prenom'];
											$_SESSION['start'] = time();
											$_SESSION['expire'] = $_SESSION['start'] + (10 * 60) ;	

											
												echo "<nav class='login'><a href='show-profil.php'><span class='deconn'>profil de <b> $row[Prenom]</b></span></a>";	
												echo "<a href='logout.php'>Se déconnecter <span class='lnr lnr-arrow-right'></span></a></nav> ";
														
											}
																

													
										else {
											
											header('location: connexion-rejetee.php');			
										}



									?>
										
										
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="main-wrapper">

	
	
				<div class="container">
					<div class="row justify-content-center align-items-center">
					
			<!-- Start banner Area -->
			<div class="banner-area">
				<div class="container">
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-5 col-md-6 col-sm-12">
							<img class="img-fluid mx-auto d-flex" src="img/header-img.png" alt="">
						</div>
						<div class="col-lg-5 col-md-6 col-sm-12 pb-40">
							<div class="banner-content">
							<img class="img-fluid" src="img/title-img.png" alt=""> 
								<h1>Rencontre Metiers</h1>
								<p class="p-2 mb-30">inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards – especially in the workplace.</p>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End banner Area -->
			<!-- Start feature Area -->
			<section class="feature-area pt-100 pb-100">
				<div class="container">
					<div class="row align-items-center justify-content-center">
                        <div class="col-lg-12 pb-30">
							<!-- <div class="section-title text-center">
								<h3 class="title-bg text-uppercase">Our Offred Services</h3>
							</div> -->
						</div>
						<div class="col-lg-6 feature-left">
							<div class="single-feature d-flex justify-content-start align-items-top">
								<div class="count">
									<h1>01</h1>
								</div>
								<div class="desc">
									<h2>Avez-vous besoin d'un matériau ou d'un produit?</h2>
									
                                    <a href="#" class="header-btn primary-btn d-inline-flex align-items-center"><span class="mr-10">Voir annonces</span><span class="lnr lnr-arrow-right"></span></a>
								</div>
							</div>
						
							
						</div>
						<div class="col-lg-4 feature-right">
							<img class="img-fluid mx-auto d-flex" src="img/ft1.jpg" alt="">
						</div>
					</div>
				</div>
			</section>
			<!-- End feature Area -->
			<!-- Start service Area -->
			<section class="service-area pt-100 pb-100">
				<div class="container">
					<div class="row align-items-center justify-content-center">
						
						<div class="col-lg-4 col-md-6 service-img">
							<img class="img-fluid" src="img/s1.jpg" alt="">
						</div>
						<div class="col-lg-6 col-md-6 text-right">
                           
								<div class="desc">
                                    <h1>02	</h1>
									<h2> <span>Vous offrez un service dans votre métier ou en cherchez un?</span></h2>
									
								</div>
							
							<button class="primary-btn hover d-inline-flex align-items-center"><span class="mr-10">Voir annonces</span><span class="lnr lnr-arrow-right"></span></button>
						</div>
					</div>
					
				</div>
			</section>
			<!-- End service Area -->
			<!-- Start project Area -->
			<section class="feature-area pt-100 pb-100">
				<div class="container">
					<div class="row align-items-center justify-content-center">
                        
						<div class="col-lg-6 feature-left">
							
						
							<div class="single-feature d-flex justify-content-start align-items-top">
								<div class="count">
									<h1>03</h1>
								</div>
								<div class="desc">
									<h2>Partagez vos expériences avec vos collègues et trouvez des solutions et des conseils pour vos travaux</h2>
									
                                    <a href="forum/forum.php" class="header-btn primary-btn d-inline-flex align-items-center"><span class="mr-10">Rejoignez nos forums</span><span class="lnr lnr-arrow-right"></span></a>
								</div>
							</div>
						</div>
						<div class="col-lg-4 feature-right">
							<img class="img-fluid mx-auto d-flex" src="img/partager.jpg" alt="">
						</div>
					</div>
				</div>
			</section>
			<!-- End project Area -->
			<!-- Start Newsletter Section -->
			<section class="newsletter-area pt-100 pb-100">
				<div class="container">
					<div class="row justify-content-center align-items-center">
						<div class="text-center">
							
						
						</div>
					</div>
				</div>
			</section>
			<!-- End Newsletter Section -->
			
		
				</div>
			</div>				

			
			<!-- Start Footer Section -->
			<footer class="footer-area pt-100 pb-20">
				<div class="container">
					<div class="row">

						<div class="col-lg-2 col-sm-6">
							
						</div>
						
						<div class="col-lg-2 col-sm-6">
							<div class="single-footer-widget">
								<h6 class="text-uppercase mb-20">Mon compte</h6>
								<ul class="footer-nav">
									<li><a href="#">Creer un compte</a></li>
									<li><a href="#">Changer le mot de passe</a></li>
									<li><a href="#">Mot de passe oublié?</a></li>
									
								</ul>
							</div>
						</div>
						<div class="col-lg-2 col-sm-6">
							<div class="single-footer-widget">
								<h6 class="text-uppercase mb-20">Services</h6>
								<ul class="footer-nav">
									<li><a href="#">Matériaux &amp; Produits  </a></li>
									<li><a href="#">Services &amp; Emplois</a></li>
									<li><a href="#">Forum </a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-2 col-sm-6">
							<div class="single-footer-widget">
								<h6 class="text-uppercase mb-20">Confidentialité</h6>
								<ul class="footer-nav">
									<li><a href="#">Terms and conditions</a></li>
									
								</ul>
							</div>
						</div>
						<div class="col-lg-4 col-sm-6">
							<div class="single-footer-widget">
								<h6 class="text-uppercase mb-20">Contact</h6>
								
								<p>
									+1 514 632 6542 <br>
									support@rencontre.metiers.com
								</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						<p class="footer-text m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
					</div>
				</div>
			</footer>
			<!-- End Footer Section -->
		</div>
		<script src="js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="js/vendor/bootstrap.min.js"></script>
		<script src="js/jquery.ajaxchimp.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.nice-select.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/main.js"></script>
        
	</body>
</html>




