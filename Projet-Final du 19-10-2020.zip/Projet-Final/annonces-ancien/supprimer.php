<?php

require_once("./model/annoncesModel.inc.php");
session_start();
$tabRes = array();


