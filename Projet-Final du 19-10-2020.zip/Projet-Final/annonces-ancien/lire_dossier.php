<?php

$whitelist = [
    "png",
    "jpg",
    "jpeg",
    "gif"];

function lesfichiers(){

    $images = preg_grep('/\.(jpe?g|png|gif)$/i', glob('./uploads/annonces*.*'));//ici juste tableau les images
    sort($images);
    print_r($images);
    
    $videos = preg_grep('/\.(mp4)$/i', glob('./uploads/annonces*.*'));//ici juste tableau les videos
    sort($videos);
    print_r($videos);

    $documents = preg_grep('/\.(doc|pdf|txt|rtf|docx)$/i', glob('./uploads/annonces*.*'));//ici juste tableau les videos
    sort($documents);
    print_r($documents);
    
}

lesfichiers();
?>