
<?php
    require_once("./model/annoncesModel.inc.php");
    
    include('./headergene.php');
    include('./header.php');
    echo "<br><br><br> <br><br> <h3 class=container > $_SESSION[prenom] vos annonces ici: </h2>";
    $idmembres = $_SESSION['id'];


    //affiche chaque card
    function affiche_card($donnee){
        
        global $idmembres;
        if($donnee->type_action =="donner") $type_action = "offre";
        $card = "<br><br><div class=\"card\">\n";
        $card.= "  <h5 class=\"card-header\">$donnee->titre : $type_action $donnee->type_annonces </h5>\n";
        
        if($idmembres > 0) {
            $card.= "    <form onsubmit='return effacer($donnee->idannonces)' ><input type='submit' class=\"btn btn-danger\" value='x'></form>";
        }$card.= "  <div class=\"card-body\">\n";
        $card.= "    <h5 class=\"card-title\"> $donnee->type_annonces </h5>\n";
        $card.= "    <h6 class=\"card-text\">Adresse : $donnee->lieu</h6>\n";
        $card.= "    <div class=\"card-text\" '>";

        $card.="<p>\n";
        $card.="  <a class=\"btn btn-primary\" data-toggle=\"collapse\" href=\"#collapseExample$donnee->idannonces\" role=\"button\" aria-expanded=\"false\" aria-controls=\"collapseExample\">\n";
        $card.="    Voir plus\n";
        $card.="  </a>\n";
        $card.="</p>\n";
        $card.="<div class=\"collapse\" id=\"collapseExample$donnee->idannonces\">\n";
        $card.="  <div class=\"card card-body\">\n";
        $card.= "       $donnee->message\n";
        $card.= "       <div>". affiches($donnee)."</div>\n";
        $card.="  </div>\n";
        $card.="</div>";
    
        $card.= "    </div>\n";
        $card.= "  </div>\n";
        $card.= "    <p class=\"card-text\">Publiée le : $donnee->date</p>\n";
        $card.= "    <div style='display:inline'><span class=\"primary-btn hover d-inline-flex align-items-center ns\"><span class=\"mr-10\"><a href=\"./annonce.php?id=$donnee->idannonces\" \">Détails</a></span></span>";
        if($idmembres > 0) {
            $card.= "    <form action='./annonce_update.php?id=$donnee->idannonces' method='post'> <input type='hiddden' name='idannonces' id='idannonces' value=$donnee->idannonces hiddden=true style='display:none'>";
            $card.= "<button type=submit class=\"primary-btn hover d-inline-flex align-items-center ns\"><span class=\"mr-10\">";
            $card.= "Modifier</span><span class=\"lnr lnr-arrow-right\"></span></button>";
            $card.= "</form>";
        }
        $card.= "  </div>\n";
        $card.= "</div>\n<br>";
        return $card;
    }


    //affiche les fichiers joints à l'annonce
    function affiches($fichiers){
        $content = "<div >";
        
            $content.=lefichier($fichiers->fichier1);
            $content.=lefichier($fichiers->fichier3);
            $content.=lefichier($fichiers->fichier2);
        
        $content.= "</div>";
        return $content;
    }

    //selectionne les fichiers joints à l'annonce
    function lefichier($data){
        $extension=strrchr($data,'.');
        
        $affiche="";
        if(strpos($extension, ".doc") > -1 || strpos($extension, ".docx") > -1 || strpos($extension, ".pdf") > -1){
            $affiche = "<br><div><a href=./uploads/docs/$data >$data </a></div>";
            return $affiche;
        }
        else
        if( strpos($extension, ".mp4") > -1){
            $affiche = "<video width=\"320\" height=\"240\" controls><source src=./uploads/videos/$data type='video/mp4' ></video>";
            return $affiche;
        }else 
        if(strpos($extension, ".jpg") > -1 || strpos($extension, ".jpeg") > -1 || strpos($extension, ".png") > -1){
            $affiche = "<img src=./uploads/photos/$data width=\"320\" height=\"240\" alt=image>";
            return $affiche;
        } 
    }


        //liste de tous les annonces enregistrées
        function liste(){
            global $tabRes,$idmembres;

            $req = "SELECT * FROM annonces WHERE idmembres=$idmembres ORDER BY idannonces DESC";
            
            $unModele = new annoncesModel($req);//
            $sth = $unModele->executer();
        
            $count=0;

            echo "<div class='container'>";
            while( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
                echo affiche_card($row);
                //$tabRes['liste'][$count++] = $row;
            }
            echo "</div>";
            
            unset($sth);
            unset($unModele);
        
        }
        
        liste();

    ?>
    <button class="primary-btn hover d-inline-flex align-items-center ns"><a href="./"><span class="mr-10">
Retour</span><span class="lnr lnr-arrow-left"></span></a></button><br><br>

                    </div> 
                </div> 
            </div> 
        </div>
		<script src="../js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="../js/vendor/bootstrap.min.js"></script>
		<script src="../js/jquery.ajaxchimp.min.js"></script>
		<script src="../js/owl.carousel.min.js"></script>
		<script src="../js/jquery.nice-select.min.js"></script>
		<script src="../js/jquery.magnific-popup.min.js"></script>
        <script src="../js/main.js"></script>
        <script src="./requetes/delete.js"></script>
        
        
	</body>
</html>