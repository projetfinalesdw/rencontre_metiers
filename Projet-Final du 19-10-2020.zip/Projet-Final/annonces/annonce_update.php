
<?php require_once("./model/annoncesModel.inc.php");
include('headergene.php'); ?>
<br><br>
<h3 class="container">Modification d'une annonce</h3> <br>
<?php
    
    include('header.php');
    
    $user_id =  $_SESSION['id'];
    $annonce_id = $_POST["idannonces"];
    $_SESSION['idannonces'] = $annonce_id;

    function leform($data){ 
        global $user_id, $annonce_id ;

        $form= "          <!-- formulaire d'enregistrement de l'annonce -->\n";
        $form.= "            <div class='container'><form action=\"./update.php\" method=\"post\" id=\"update \" enctype=\"multipart/form-data\"  onsubmit=\"return update(this)\" class='container'>\n";
        $form.= "                    <input type=\"text\" name=\"idmembres\" value=$user_id  style='display:none' >\n";
        $form.= "                    <input type=\"text\" name=\"idannonces\" value=$annonce_id  style='display:none' >\n";
        $form.= "                    <div class=\"form-group\">\n";
        $form.= "                      <label for=\"titre\">Titre</label>\n";
        $form.= "                      <input type=\"text\" class=\"form-control validate\" id=\"titre\" name=\"titre\" value='$data->titre'  placeholder=\"Titre de l'annonce\" autofocus=\"true\" required > \n";
        $form.= "                      \n";
        $form.= "                    </div>\n";
        $form.= "                    <div class=\"form-group\">\n";
        $form.= "                      <label for=\"type_annonces\">De quel type d'annonce s'agit-il?</label>\n";
        $form.= "                      <select class=\"form-control\" id=\"type_annonces\" name=\"type_annonces\"> \n";
        $form.= "                          <option value=\"$data->type_annonces\" selected >$data->type_annonces</option>\n";
        $form.= "                          <option value=\"emploi\">emplois</option>\n";
        $form.= "                          <option value=\"benevolat\">bénevolat</option>\n";
        $form.= "                          <option value=\"produit\">produit</option>\n";
        $form.= "                          <option value=\"materiel\">materiel</option>\n";
        $form.= "                          <option value=\"stage\">stage</option>\n";
        $form.= "                      </select>\n";
        $form.= "                    </div>\n";
        $form.= "                    <div class=\"form-group \">\n";
        $form.= "                      <label class=\"form-label\" for=\"type_action\">Que voulez-vous faire?</label>\n";
        $form.= "                      <select class=\"form-control\"  name=\"type_action\" id=\"type_action\">\n";
        $form.= "                        <option value=\"$data->type_action\" selected >$data->type_action</option>\n";
        $form.= "                        <option value=\"donner\">donner</option>\n";
        $form.= "                        <option value=\"louer\">louer</option>\n";
        $form.= "                        <option value=\"vendre\">vendre</option>\n";
        $form.= "                      </select>\n";
        $form.= "                    </div>\n";
        
        $form.= "                    <div class=\"form-group\">\n";
        $form.= "                        <label for=\"lieu\">Adresse du lieu</label>\n";
        $form.= "                        <input class=\"form-control\" type=\"address\" class=\"form-control validate\" value='$data->lieu'  id=\"lieu\" name=\"lieu\" placeholder=\"Entrer l'adresse du lieu\" required>\n";
        $form.= "                    </div>\n";
        $form.= "                    <div class=\"form-group\">\n";
        $form.= "                        <label for=\"lieu\">Contenu de votre message:</label>\n";
        $form.= "                        <textarea class=\"form-control validate\" name=\"message\" id=\"message\" cols=\"30\" rows=\"10\" placeholder=\"Votre annonce ici\">$data->message </textarea>";

        //$form.= "                       <input type=\"file\" name=\"fichier\" id=\"fichier\">" ;
        $form.= " \n";
        $form.= "                    <div class=\"form-group\">\n";
        $form.= "                      <h3>Ajouter des fichiers à votre annonces: </h3>\n";
        $form.= "                      <input type=\"file\" name=\"files\" multiple=\"true\" id=\"basic\">\n";
        $form.= "                      <div id=\"basic_drop_zone\" class=\"dropZone\"><br><div>Drop files here</div></div>\n";
        $form.= "                      <div id=\"basic_progress\"></div>\n";
        $form.= "                      <div id=\"basic_message\"></div>\n";
        $form.= "                    </div>\n";
        $form.= "                    <div class=\"form-group\">\n";
        $form.= "                      <span id=\"msg\"></span>\n";
        $form.= "                    </div>\n";
        $form.= "                    <a href='./' class=\"btn btn-secondary\">Retour</a></form>";
        $form.= "                    <button type='submit'  class=\"btn btn-primary\" onclick=\" \">Envoyer</button>";
        $form.= "                    </div>";
        return $form;
    }
    
    
    function liste(){
        global $tabRes,$annonce_id;

        $req = "SELECT * FROM annonces WHERE idannonces='$annonce_id' ";
        
        $unModele = new annoncesModel($req);//,[$categ]
        $sth = $unModele->executer();
       
        $count=0;
        if( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
            echo leform($row);
            //$tabRes['liste'][$count++] = $row;
        }
        
        //$unModele->lastInsertId();//déconnexion
        unset($sth);
        unset($unModele);
       
    }
    
    liste();
    ?>

  <script>
  $('#basic').simpleUpload({
    url: './postphoto.php',
    method: 'post',
    maxFileNum: 4,
    //maxFileSize: 20480,
    allowedFileName: /(\.txt|\.jpg|\.png|\.jpeg|\.mp4|\.pdf|\.doc|\.docx\/)/,
    allowedMimeType: /(text|image|document|video|pdf|doc|docx\/)/,
    params: { key: 'test' },
    ajax: {
      headers: { 'X-Test': 'test' },
      statusCode: {
        200: function() {
          console.log('success!');
        }
      }
    },
    dropZone: '#basic_drop_zone',
    progress: '#basic_progress'
  }).on('upload:before', function(e, files) {
    console.log('before');
    console.log(files);
  }).on('upload:after', function(e, files) {
    console.log('after');
    console.log(files);
  }).on('upload:start', function(e, file, i) {
    console.log('start ' + i);
    console.log(file);
  }).on('upload:progress', function(e, file, i, loaded, total) {
    console.log('progress ' + i + ' ' + loaded + '/' + total);
  }).on('upload:end', function(e, file, i) {
    console.log('end ' + i);
    console.log(file);
  }).on('upload:done', function(e, file, i) {
    console.log('done ' + i);
    console.log(file);
    $('#basic_message').prepend('<p>done: ' + file.name + '</p>');
  }).on('upload:fail', function(e, file, i) {
    console.log('fail ' + i);
    console.log(file);
    $('#basic_message').prepend('<p>fail: ' + file.name + '</p>');
  }).on('upload:over', function(e, files) {
    alert('Number of files is over');
  }).on('upload:invalid', function(e, files) {
    for (var i=0; i<files.length; i++) {
      alert('Invalid ' + files[i].reason + ': ' + files[i].name);
    }
  });

  </script>


  <script src="./requetes/create.js"></script>
  <script src="./requetes/script.js"></script>
  <script src="./requetes/update.js"></script>

<?php include("footergene.php"); ?>