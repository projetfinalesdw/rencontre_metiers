<?php

require_once("./model/annoncesModel.inc.php");
session_start();
$tabRes = array();
$last_insert_id;

  function epurerDonnees($donnees){
        $donnees = trim($donnees);
        $donnees = stripslashes($donnees);
        $donnees = htmlspecialchars($donnees);
        return $donnees;
    }
	
    //create une annonce
    function create(){ 
        global $tabRes, $last_insert_id;
		
        
            //if(isset($_POST['submit'])){
                $video="";  $photo=""; $doc="";
              
                $letitre = epurerDonnees( $_POST['titre']);
                //$idmetier =  epurerDonnees( $_POST['metier']);
                $message=  epurerDonnees( $_POST['message']);
                $type_annonces =  epurerDonnees( $_POST['type_annonces']);
                $idmembres=  epurerDonnees( $_POST['idmembres']);
                $type_action=  epurerDonnees( $_POST['type_action']);
                $lieu=  epurerDonnees( $_POST['lieu']);
                $nombrevues=  0;
                $now = new DateTime('NOW');
                //print_r($now);
                echo "<br>";
                $a = get_object_vars($now);
                $createddate = $a["date"];
                //print_r($createddate);
                echo "<br>";

                $titre = sha1($letitre.time());
            try{
                $requete="INSERT INTO annonces VALUES(0,?,?,?,?,?,?,?,?,?,?,?)";

                //insérer les fichiers
                
                //if(count($_FILES["fichier"]['tmp_name']) > 0)
                for($e=0; $e < 3; $e++){
                    if(  $_FILES["fichier"]['tmp_name'][$e] !== "" ){
                        
                        echo " <br>Le type du fichier ".$e." est ".$_FILES["fichier"]['type'][$e]."<br>";
                        //$tabRes['error']="La taille du fichier ".$e." est ".$_FILES["fichier"]['size'][$e]."<br>";
                        
                        $tmp = $_FILES["fichier"]['tmp_name'][$e];
                        //$check = getimagesize($_FILES["pochette"]["tmp_name"]);
                        //$taille = $_FILES["fichier"]["size"];
                        $fichier = $_FILES["fichier"]['name'][$e];
                        $extension=strrchr($fichier,'.');
                        
                        //move_uploaded_file($tmp,$dossier.$nomPochette.$extension);
                        
                        //Upload d'une vidéo
                        if(strpos($_FILES["fichier"]['type'][$e] , "video") > -1){ 
                            $video =  $titre.$extension;
                            $dossier="./uploads/videos/";
                        
                            if(@move_uploaded_file($tmp,$dossier.$titre.$extension)){
                                echo "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." a été bien envoyé.";
                                
                            }else{
                                echo "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." n'a pas été bien envoyé.";
                                $tabRes['msg_video'] = "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." n'a pas été bien envoyé.";
                           }
                        }else if(strpos($_FILES["fichier"]['type'][$e] , "image") > -1){
                            $photo = $titre.$extension;
                            $dossier="./uploads/photos/";
                            if(@move_uploaded_file($tmp,$dossier.$titre.$extension)){
                                echo "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." a été bien envoyé.";

                            }else{
                                     $tabRes['msg_image'] = "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." n'a pas été bien envoyé.";
                                echo "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." n'a pas été bien envoyé.";

                            }
                        }else if(strpos($_FILES["fichier"]['type'][$e] , "document") > -1 || strpos($_FILES["fichier"]['type'][$e] , "pdf") > -1){
                            $doc = $titre.$extension;
                            $dossier="./uploads/docs/";
                            if(@move_uploaded_file($tmp,$dossier.$titre.$extension)){
                                echo "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." a été bien envoyé.";

                            }else{
                                  $tabRes['msg_doc'] = "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." n'a pas été bien envoyé.";
                                   echo "<br>Le fichier ".$_FILES["fichier"]['name'][$e]." de type ".$_FILES["fichier"]['type'][$e]." n'a pas été bien envoyé.";

                            }
                        }

                        //// Enlever le fichier temporaire chargé
                        @unlink($tmp); //effacer le fichier temporaire
                    }
            }
             //fin insertion des fichiers

                    $tabDonnees = [$letitre,$createddate,$message,$type_annonces,$idmembres,$type_action,$lieu,$nombrevues,$video,$photo,$doc];
                    $unModele = new annoncesModel($requete,$tabDonnees );
                    $stmt = $unModele->executer();
                    $tabRes['action']="create";
                    $tabRes['ok']="Votre annonce est bien enregistrée.";
                   // $tabRes['current_user_id'] =  $unModele->lastInsertId();
                   
                    $last_insert_id = $unModele->last_id_insert();
                    $tabRes['lastInsertId'] = $last_insert_id;
                  /*  */
            }catch(PDOException $e){
                $Log['error'] = [$e->getMessage()];
                $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
				echo $e->getMessage();
			}finally{
                unset($unModele);
                unset($stmt);
                header("Location:index.php");
            }
       // }

    } //Fin create annonce

    create();

    $_SESSION['last_insert_id'] = $last_insert_id;

    echo json_encode($tabRes);
    //******************************************************