<?php

$whitelist = [
    "png",
    "jpg",
    "jpeg",
    "gif"
];

function lesfichiers(){

    $images = preg_grep('/\.(jpe?g|png|gif)$/i', glob('./uploads/annonces*_*'));//ici juste tableau les images
    sort($images);
    //print_r($images);
    if(count($images) > 0){
        foreach($images as $img){
            echo "<br>";
             echo "<img src='$img' alt='image' width='200' height='300' >";
             decoupe($img);
        }
       
    }
    
    $videos = preg_grep('/\.(mp4)$/i', glob('./uploads/annonces*_*'));//ici juste tableau les videos
    sort($videos);
    //print_r($videos); 
    // $target.$sources."_".$idannonces."_".$idmembres."_".$_FILES["files"]["name"]

    if(count($videos) > 0){
        foreach($videos as $vid){
            echo "<br>";
            echo "<video width=\"320\" height=\"240\" controls>\n";
            echo "  <source src=\"$vid\" type=\"video/mp4\">\n";
            echo "</video>";
            decoupe($vid);
        }
       
    }

    $documents = preg_grep('/\.(doc|pdf|txt|rtf|docx)$/i', glob('./uploads/annonces*_*'));//ici juste tableau les videos
    sort($documents);
    //print_r($documents);
    if(count($documents) > 0){
        foreach($documents as $doc){
            echo "<br>";
            echo "<a href='$doc'>Document lié</a>";
            decoupe($doc);
        }
       
    }
    
}


function decoupe($t){
    $tab = (explode('_',$t));
    echo "<br>";
    echo "id annonce : ".$tab[1]." ; id membre : ".$tab[2]." ; nom du fichier : ".$tab[3]."<br>";
    $id_an = $tab[1];
    $id_mem = $tab[2];
    $fichier = $tab[3];
}

lesfichiers();
?>