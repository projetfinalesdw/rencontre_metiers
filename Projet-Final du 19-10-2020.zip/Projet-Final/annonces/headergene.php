<?php session_start(); ?>

<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Annonces - Rencontres des professionnels des métiers</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="../css/linearicons.css">
		<link rel="stylesheet" href="../css/owl.carousel.css">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/nice-select.css">
		<link rel="stylesheet" href="../css/magnific-popup.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		
			

	</head>
	<body>
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="../index.html"><img src="../img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
									<nav class="hide">
										<a href="../index.html">Home</a>
										<!-- <a href="../generic.html">Matériaux ou produits</a> -->
										<a href="./">Services ou emplois</a>
										<a href="../forum.html">Forums</a>
									</nav>

									<?php 
									if($_SESSION)
										if( $_SESSION['id']){
											$id_membre = $_SESSION['id']; 
											$prenom =  $_SESSION['prenom'];
											echo "<nav class='login'><a href='show-profil.php'><span class='deconn'>profil de <b> $prenom </b></span></a>";	
											echo "<a href='logout.php'>Se déconnecter <span class='lnr lnr-arrow-right'></span></a></nav> ";
											}else{
											echo "<a href=\"../inscription.html\">Créer un compte</a>";
											echo "<a href=\"../index.html#openModal14\">Se connecter</a>";
										
										}
										?>
									
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
		<div class="main-wrapper">
        <br><br>
			<!-- Start banner Area 
			<div class="banner-area">
				<div class="container">
					<div class="section-top-border">-->
