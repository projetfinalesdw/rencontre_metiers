
function valider(id){ //à compléter
	var form = document.getElementById(id);
		if(form.titre.value.trim() !=""){
			form.titre.style.backgroundColor="white";
		}	if(form.lieu.value.trim() !=""){
			form.lieu.style.backgroundColor="white";
		}	if(form.message.value.trim() !=""){
			form.message.style.backgroundColor="white";
		}

	if(form.titre.value.trim() !="" && form.lieu.value.trim() != "" && form.message.value.trim() != ""){
						
		return true;
	}else{
		$("#msg").html("Veuillez revoir ces erreurs s'il vous plait!");
		$("#msg").css('color','red');
		if(form.titre.value.trim() ==""){
			form.titre.style.backgroundColor="pink";
			console.log(form.titre.name + " vide");
		}else if(form.lieu.value.trim() ==""){	
			console.log(form.lieu.name + " vide");
			form.lieu.style.backgroundColor="pink";
		}else if(form.message.value.trim() ==""){
			console.log(form.message.name + " vide");
			form.message.style.backgroundColor="pink";
		}
			
		return false;
	}
    
}

//console.log($('#create').children('input'));


//enregistrer  
function create(formId,btn){
	var form = new FormData(document.getElementById(formId));
    form.append('action',formId);
    
		//console.log("retour = " + valider(formId));
	if(val = valider(formId)){
		//btn.disabled = true;
		console.log("retour = " + val);
		$.ajax({
			type : 'POST',
			url : './create.php',
			data : form,
			dataType : 'json', //text pour le voir en format de string
			async : true,
			cache : false,
			contentType : false,
			processData : false,
			success : function (reponse){
				//alert(reponse);
				var msg="";
				if(reponse.ok ){
					msg = reponse.ok;
					btn.disabled = false;
					$("#"+formId+" input[type=text]").each(function(index,valeur){
						valeur.value="";
					});
					$("#msg").css("color","green");
					msg += "<br>"+reponse.msg_video;
					msg += "<br>"+reponse.msg_image;
					msg += "<br>"+reponse.msg_doc;
				}else{
					msg = reponse.error;
					msg += "<br>"+reponse.msg_video;
					msg += "<br>"+reponse.msg_image;
					$("#msg").css("color","red");
					btn.disabled=false;
					alert(msg);
				}
				$("#msg").html(msg);
				alert(msg);
				setTimeout(function(){
					$("#msg").html("");
					btn.disabled=false;
				},5000);
				
			},
			fail : function (err){
				$("#msg").html(err);
			}
		});
	}else{console.error("Erreur d'enregistrement de votre annonce!")}
}

