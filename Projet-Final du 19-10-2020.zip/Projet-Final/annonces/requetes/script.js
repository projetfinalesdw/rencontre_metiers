//var sessionStorage = new sessionStorage();


//remplir les inputs avec les données de sessionStorage
function chargerInputs1(formId){//charger enregistrerUsager
		
    tabObjet=JSON.parse(sessionStorage.getItem(formId));

        leFormul = document.create;
        $(" .badge1").remove();
    if(tabObjet){
        leFormul.titre.value = tabObjet[0][0];
        leFormul.prenom.value = tabObjet[0][1];
        leFormul.nom.value = tabObjet[0][2]; 
        leFormul.email.value  = tabObjet[0][3];
        leFormul.reclammation.value  = tabObjet[0][4];
        leFormul.date_naiss.value  = tabObjet[0][5];
    }else{
        
        msg="<div class='badge badge1 badge-warning'>Données du formulaire non encore sauvegardées! </div>";
        $("#"+formId).append(msg);
        leFormul.submit.focus();
    }
}