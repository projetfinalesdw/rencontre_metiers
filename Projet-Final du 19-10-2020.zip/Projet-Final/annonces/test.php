<?php
$i=0;$target = "./uploads/";
move_uploaded_file($_FILES["fichier"]["tmp_name"][$i],
    $target.$_FILES["fichier"]["name"][$i]
);