<?php
    ///////////////
     require_once("./../annonces/connexion/connection.inc.php");
    class annoncesModel{
        private $requete;
        private $params;//tableau des données à envoyer au server
        private $connexion;
        public $id_connect;
        public $id_insert;
        
    function __construct($requete=null,$params=null){
            $this->requete=$requete;
            $this->params=$params;
    }
    function obtenirConnexion(){
        $maConnexion = new Connexion( "localhost", "root", "", "rencontres");
        $this->id_insert = $maConnexion->connecter();
        return $maConnexion->getConnexion();
    }

    function executer(){
            $this->connexion = $this->obtenirConnexion();
            $stmt = $this->connexion->prepare($this->requete);
            $stmt->execute($this->params);
            return $stmt;		
        }
    function deconnecter(){
            unset($this->connexion);
    }
    
    function last_id_insert(){
        return $this->connexion->query('SELECT LAST_INSERT_ID()')->fetch(PDO::FETCH_ASSOC)['LAST_INSERT_ID()'];
    }
    
    /*
    function lastInsertId(){
            $this->connexion = $this->obtenirConnexion();
            $id = $this->connexion->lastInsertId();
            $this->deconnecter(); //fermer la connexion
        return $id ;
    }
    */

 }//fin de la classe modele