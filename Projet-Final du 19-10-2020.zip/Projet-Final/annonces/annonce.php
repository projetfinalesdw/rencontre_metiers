<!-- Ce fichier affiche les détails d'une annonces -->
<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Colorlib">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Layal</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500,600" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="../css/linearicons.css">
		<link rel="stylesheet" href="../css/owl.carousel.css">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/nice-select.css">
		<link rel="stylesheet" href="../css/magnific-popup.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
		
			

	</head>
	<body>
		<div class="main-wrapper-first">
			<div class="hero-area relative">

				
				<header>
					<div class="container">
						
						
						<div class="header-wrap">
							<div class="header-top d-flex justify-content-between align-items-center">
								
								<div class="logo">
									<a href="../index.html"><img src="../img/logo.png" alt=""></a>
								</div>
							
								<div class="main-menubar d-flex align-items-center">
									<nav class="hide">
										<a href="../index.html">Home</a>
										<!-- <a href="../generic.html">Matériaux ou produits</a> -->
										<a href="./">Services ou emplois</a>
										<a href="../forum.html">Forums</a>
									</nav>

									<nav class="login">
										<a href="../s'inscrire.html">Créer un compte</a>
										<a href="../index.html#openModal14">Se connecter</a>
										
									</nav>
									<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
								</div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</div>
        <div class="main-wrapper">
			<!-- Start banner Area -->
			<div class="banner-area">
				<div class="container">
					<div class="section-top-border">


<?php
require_once("model/annoncesModel.inc.php");
include("header.php");
$idannonces;
function annonce(){
    global $tabRes,$array,$idannonces;

$array = explode("&",$_SERVER['QUERY_STRING']);
$first_arg = explode("=",$array[0]); 
$val = $first_arg[1];
$idannonces = $val;
//echo count($array);
echo "<br><br>";
 
 if(count($array) > 0 ){
    $req = "SELECT * FROM annonces WHERE idannonces='$val'";
    
    $unModele = new annoncesModel($req);//,[$categ]
    $sth = $unModele->executer();
   
    $count=0;
        
        if( $row = $sth->fetch( PDO::FETCH_OBJ)  ){
            echo "<div class=container>";
                echo affiche_card($row);
            echo "</div>";
            //$tabRes['liste'][$count++] = $row;
            unset($sth);
            unset($unModele);
        }else{
             echo "Ooops! Désolé aucune annonce :(";
        }
    }else{
            echo "Ooops! Erreur! Désolé rien à faire :(";
    }
   
}


function affiche_card($donnee){
    global $idannonces;
    $card = "<div class=\"card\">\n";
    $card.= "  <h5 class=\"card-header\"><span>($donnee->nombrevues)</span>&nbsp;$donnee->titre</h5>\n";
    $card.= "  <div class=\"card-body\">\n";
    $card.= "    <h5 class=\"card-title\"> $donnee->type_annonces à $donnee->type_action</h5>\n";
    $card.= "    <h6 class=\"card-text\">$donnee->lieu</h6>\n";
    $card.= "    <div class=\"card-text\">$donnee->message</div>\n";
    $card.= "    <p class=\"card-text\">Publiée le : $donnee->date</p>\n";
    $card.= "       <div>". affiches($donnee)."</div>\n";
    $card.= "    <a href=\"../annonces/\" class=\"btn btn-primary\">Retour</a>\n";
    $card.= "  </div>\n";
    $card.= "</div>\n<br>";
    increment_vues($donnee->nombrevues, $idannonces);
    return $card;
}

function increment_vues($a, $ida){
    $i = intval($a);
    $i++;
    $nombrevues = $i;
    try{

            //mise à jour des vues de l'annonce

                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "rencontres";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
                }

                $sql = "UPDATE annonces SET nombrevues='$nombrevues' WHERE idannonces=$ida";

                if ($conn->query($sql) === TRUE) {
                echo "<br><br>Détails de l'aonnonce<br>".$nombrevues."ème vue.";
                } else {
                echo "Error updating record: " . $conn->error;
                }


    }catch(PDOException $e){
        $Log['error'] = [$e->getMessage()];
        $tabRes['error']="Oups probleme d'enregistrement, ".$e->getMessage();
        echo $e->getMessage();
    }finally{
        $conn->close();
    }
}



function lefichier($data){
    $extension=strrchr($data,'.');
    
    $affiche="";
    if(strpos($extension, ".doc") > -1 || strpos($extension, ".docx") > -1 || strpos($extension, ".pdf") > -1){
        $affiche = "<br><div><a href=./uploads/docs/$data >Fichier joint : $data </a></div>";
        return $affiche;
    }
    else
    if( strpos($extension, ".mp4") > -1){
        $affiche = "<video width=\"320\" height=\"240\" controls><source src=./uploads/videos/$data type='video/mp4' ></video>";
        return $affiche;
    }else 
    if(strpos($extension, ".jpg") > -1 || strpos($extension, ".jpeg") > -1 || strpos($extension, ".png") > -1){
        $affiche = "<img src=./uploads/photos/$data width=\"320\" height=\"240\" alt=image>";
        return $affiche;
    } 
}

function affiches($fichiers){
    $content = "<div >";
    
        $content.=lefichier($fichiers->fichier1);
        $content.=lefichier($fichiers->fichier3);
        $content.=lefichier($fichiers->fichier2);
    
    $content.= "</div>";
    return $content;
}
annonce();

?>

                    </div> 
                </div> 
            </div> 
        </div>
		<script src="../js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="../js/vendor/bootstrap.min.js"></script>
		<script src="../js/jquery.ajaxchimp.min.js"></script>
		<script src="../js/owl.carousel.min.js"></script>
		<script src="../js/jquery.nice-select.min.js"></script>
		<script src="../js/jquery.magnific-popup.min.js"></script>
        <script src="../js/main.js"></script>
        
	</body>
</html>