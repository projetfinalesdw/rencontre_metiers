<?php
    require_once("./model/annoncesModel.inc.php");
    session_start();
    $tabRes = array();


    $array = explode("&",$_SERVER['QUERY_STRING']);
    $first_arg = explode("=",$array[0]); 
    $id_annonces = $first_arg[1];

    //$_SESSION['idannonces'] = $_POST["idannonces"];
    
    $idmembres = $_SESSION['id'];

    try{
        $requete="DELETE FROM annonces  WHERE idmembres=$idmembres AND idannonces=$id_annonces ";

            $tabDonnees = [$idmembres,$id_annonces];
            $unModele = new annoncesModel($requete,$tabDonnees );
            $stmt = $unModele->executer();
            $tabRes['action']="delete";
            $tabRes['ok']="Votre annonce est bien supprimée.";
            
    }catch(PDOException $e){
        $Log['error'] = [$e->getMessage()];
        $tabRes['error']="Oups probleme de suppression, ".$e->getMessage();
        echo $e->getMessage();
    }finally{
        unset($unModele);
        unset($stmt);
        supprimer_fichiers();
        header("Location:mes_annonces.php");
    }

    function supprimer_fichiers(){
        try{
            $requete="SELECT fichier1, fichier2, fichier3 FROM annonces  WHERE idannonces=$id_annonces";
    
                $tabDonnees = [$idmembres,$id_annonces];
                $unModele = new annoncesModel($requete,$tabDonnees );
                $stmt = $unModele->executer();

                $i=1;
                while( $row = $stmt->fetch( PDO::FETCH_OBJ)  ){

                    if(is_file("./uploads/docs/$row->fichier.$i") ){
                        unlink("./uploads/docs/$row->fichier.$i");
                    }

                    if(is_file("./uploads/photos/$row->fichier.$i") ){
                        unlink("./uploads/photos/$row->fichier.$i");
                    }
                    
                    if(is_file("./uploads/videos/$row->fichier.$i") ){
                        unlink("./uploads/videos/$row->fichier.$i");
                    }
                    unlink("./uploads/photos/$row->fichier.$i");
                    unlink("./uploads/photos/$row->fichier.$i");
                    unlink("./uploads/docs/$row->fichier.$i");
                    $i++;
                }
                
        }catch(PDOException $e){
        }finally{
            unset($unModele);
            unset($stmt);
        }
    }
